# PEP 006 - RC konstanta

![plot](006_sch.png)
![plot](006_pcb.png)

